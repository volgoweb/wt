# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('task', '0001_initial'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='task',
            name='comments',
        ),
        migrations.RemoveField(
            model_name='task',
            name='desc',
        ),
        migrations.RemoveField(
            model_name='task',
            name='files',
        ),
        migrations.RemoveField(
            model_name='task',
            name='id',
        ),
        migrations.RemoveField(
            model_name='task',
            name='performer',
        ),
        migrations.RemoveField(
            model_name='task',
            name='polymorphic_ctype',
        ),
        migrations.RemoveField(
            model_name='task',
            name='step_id',
        ),
        migrations.RemoveField(
            model_name='task',
            name='step_type',
        ),
        migrations.RemoveField(
            model_name='task',
            name='task_steps',
        ),
        migrations.RemoveField(
            model_name='task',
            name='title',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='author',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='comments',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='created',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='deleted',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='due_date',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='is_favorite',
        ),
        migrations.RemoveField(
            model_name='tasktemplate',
            name='status',
        ),
        migrations.AddField(
            model_name='task',
            name='tasktemplate_ptr',
            field=models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, default=1, serialize=False, to='task.TaskTemplate'),
            preserve_default=False,
        ),
    ]
